DRINKS PROGRESSION
1. Ice cube
2. Small shot glass
3. Whiskey glass
4. Champagne glass
5. White wine glass
6. Red wine glass
7. Martini glass
8. Long drink
9. Beer mug
10. Large cocktail glass
11. Champagne bottle
